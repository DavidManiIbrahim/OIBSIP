# Lummoh: Landing Page

**Oasis Infobyte Web Development Internship · Level 1, Task 1**

A responsive landing page for **Lummoh**, a lifestyle marketplace (motto: *"Shop with confidence"*) that connects shoppers with independent, locally made lifestyle brands. It is built with **HTML5 and CSS3 only**, with no JavaScript, frameworks, or build tools.

---

## Project Structure

```
WebDev-L1-LandingPage/
├── index.html   # Page markup (semantic HTML5)
├── style.css    # All styles, layout, and responsive rules
├── images/
│   └── hero-illustration.svg   # Original hero illustration
└── README.md    # Project documentation
```

---

## Page Sections

| # | Section | Description |
|---|---------|-------------|
| 1 | **Navigation Bar** | Sticky header with the brand logo and anchor links to `#features`, `#about`, and `#contact`. |
| 2 | **Hero** | Two-column gradient banner with a headline, a supporting subheadline, two styled call-to-action buttons, and an original illustration (it stacks under the text on smaller screens). |
| 3 | **Features** | A CSS Grid of six benefit cards, each with a line icon (curated makers, same-city delivery, fair earnings, and more). |
| 4 | **About** | A contrasting dark-green section with the brand story, a 2×2 statistics grid, and a customer testimonial. |
| 5 | **Footer** | Placeholder contact details, quick links, social media links, and copyright text. |

---

## Technical Highlights

- **Semantic HTML5:** uses `<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<blockquote>`, `<address>`, and `<footer>`.
- **Modern layout:** **Flexbox** for the navbar, buttons, and social links; **CSS Grid** for the cards, About layout, stats, and footer.
- **`box-sizing: border-box`** is applied globally so padding never causes overflow or overlapping elements.
- **CSS custom properties** (`:root` variables) define the full colour palette, fonts, and sizes in one place.
- **Responsive design:** two breakpoints, at `992px` (tablet) and `600px` (phone):
  - The cards go from 3 columns to 2, then to 1.
  - The About section stacks vertically.
  - The navbar stacks the logo above the links on phones.
  - The footer goes from 4 columns to 2, then to 1.
- **Smooth scrolling** with `scroll-behavior: smooth`, plus `scroll-padding-top` so the sticky navbar never hides section headings.
- **Accessibility:** a `lang` attribute, descriptive `aria-label`s, decorative icons hidden from screen readers, visible `:focus-visible` outlines, and strong colour contrast.
- **Icons:** inline SVG icons from [Feather Icons](https://feathericons.com) (MIT licence), the same set React Icons ships as `Fi`. They are embedded directly in the HTML, so no JavaScript or icon library is needed, and they inherit colour from CSS through `currentColor`.
- **Hero image:** a custom, hand-coded SVG illustration (shopping bag, plant, candle, and basket). It scales without blurring, stays lightweight, and works offline.
- **Hover effects:** animated nav underlines, lifting buttons and cards, and highlighted social icons, all done in pure CSS.

---

## Design System

### Colour Palette

| Role | Colour | Hex |
|------|--------|-----|
| Primary (CTA, accents) | Terracotta | `#c8553d` |
| Secondary (contrast section) | Forest Green | `#1f4e3d` |
| Footer | Deep Green | `#163a2d` |
| Highlight | Honey Yellow | `#f2a541` |
| Background | Cream | `#fbf7f1` |
| Body text | Charcoal | `#2b2b2b` |

### Typography

- **Headings:** *Playfair Display*, an elegant serif that suits a handcrafted lifestyle brand
- **Body:** *Inter*, a clean, highly readable sans-serif
- **Sizes:** Hero `3.5rem` · Section titles `2.25rem` · Card titles `1.25rem` · Body `1rem` · Small `0.875rem`

---

## How to Run

1. Download or clone this folder.
2. Open `index.html` in any modern browser (Chrome, Firefox, Edge, or Safari).
3. Resize the window or use the browser's DevTools device toolbar to test the responsive layouts.

No installation or server is needed. The fonts load from Google Fonts, so an internet connection makes them display correctly; without one, the page falls back to system fonts.

---

## Skills Demonstrated

- Semantic, well-commented HTML5 structure
- CSS3 Flexbox and Grid layouts
- Mobile-first responsive design with media queries
- Consistent design tokens using CSS variables
- Accessible, keyboard-friendly navigation

---

## Author

**David Mani Ibrahim**: Web Development Intern, Oasis Infobyte

#OasisInfobyte #WebDevelopment #Internship
